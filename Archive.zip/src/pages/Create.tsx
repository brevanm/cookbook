const Create = () => {
  return <div>create</div>;
};

export default Create;
